"""An Azure RM Python Pulumi program"""

import pulumi
from pulumi_azure_native import storage
from pulumi_azure_native import resources

# Fetch configuration values
config = pulumi.Config()
location = config.get("location") or "westeurope"  # Default to 'eastus' if not set
storage_account_name = config.get("storageAccountName") or "defaultname"
sku = config.get("sku") or storage.SkuName.STANDARD_LRS

# Create an Azure Resource Group
resource_group = resources.ResourceGroup(
    "resource_group",
    location=location,  # Use the configured location
)

# Create an Azure resource (Storage Account)
account = storage.StorageAccount(
    storage_account_name,  # Use configured storage account name
    resource_group_name=resource_group.name,
    sku={
        "name": sku,  # Use configured SKU
    },
    kind=storage.Kind.STORAGE_V2,
    location=location,  # Use the same location as the resource group
)

# Export the primary key of the Storage Account
primary_key = (
    pulumi.Output.all(resource_group.name, account.name)
    .apply(
        lambda args: storage.list_storage_account_keys(
            resource_group_name=args[0], account_name=args[1]
        )
    )
    .apply(lambda accountKeys: accountKeys.keys[0].value)
)

# Export outputs
pulumi.export("resource_group_name", resource_group.name)
pulumi.export("storage_account_name", account.name)
pulumi.export("primary_storage_key", primary_key)
